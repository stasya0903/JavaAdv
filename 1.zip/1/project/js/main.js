const products = [
  {id: 1, title: 'Notebook', price: 1000, picture:"./img/notebook.jpg", country:"Japan",  brand:"Samsung"},
  {id: 2, title: 'Mouse', price: 100, picture:"./img/mouse.jpg", country:"Korea", brand:"Asus" },
  {id: 3, title: 'Keyboard', price: 250, picture:"./img/keyboard.jpg", country:"USA", brand:"Apple" },
  {id: 4, title: 'Gamepad', price: 150, picture:"./img/gamepad.jpeg", country:"Japan",  brand:"Toshiba"},
];

const renderProduct = (item) => {
  return `<div class="product-item">
            <h3>${item.title}</h3>
            <p>Цена: ${item.price}</p>
            <img src="${item.picture}" alt="" > 
            <p>Страна производитель: ${item.country}</p>
            <p>Бренд: ${item.brand}</p>
            <button class="by-btn">Добавить</button>       
          </div>`;
};
const addDummyImg = (img) => {
    return img.onerror = ()=> img.src = "http://dummyimage.com/120"
};
const renderProducts = list => {
  document.querySelector('.products')
          .innerHTML = list.map(item => renderProduct(item)).join('');
  document.querySelectorAll("img").forEach((img) =>
      addDummyImg(img)
  )

};

renderProducts(products);





